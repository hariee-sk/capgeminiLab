package com.capgemini.ex1;

public class CurrentAccount extends Account{
	
	private int overDraftlmt;

	public int getOverDraftlmt() {
		return overDraftlmt;
	}

	public void setOverDraftlmt(int overDraftlmt) {
		this.overDraftlmt = overDraftlmt;
	}

}
