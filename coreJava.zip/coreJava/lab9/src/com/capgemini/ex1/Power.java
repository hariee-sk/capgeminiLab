package com.capgemini.ex1;

public interface Power {
	
	void power(int x,int y);

}