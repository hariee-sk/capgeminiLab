package com.capgemini.springbootex1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springbootex1.model.Wallet;

@RestController
public class WalletCollector {
	@RequestMapping("/wallet")
	public List<Wallet> showWalletDetails(){
		Wallet wal = new Wallet(11,"credit card",850.0f);
		Wallet wal1 = new Wallet(15,"smart card",500.0f);
		Wallet wal2 = new Wallet(19,"cash",200.50f);
		
		
		List<Wallet> walList = new ArrayList<Wallet>();
		walList.add(wal2);
		walList.add(wal1);
		walList.add(wal);
		
		return walList;
		
	}
}
