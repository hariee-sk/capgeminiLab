package com.capgemini.springbootex1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springbootex1.model.Order;

@RestController
public class OrderController {
	@RequestMapping("/order")
	public List<Order> showBuyerDetails(){
		Order ord = new Order(57,"Car",185000.0f);
		Order ord1 = new Order(50,"Bike",75000.0f);
		Order ord2 = new Order(78,"cycle",15000.0f);
		
		
		List<Order> ordList = new ArrayList<Order>();
		ordList.add(ord2);
		ordList.add(ord1);
		ordList.add(ord);
		
		return ordList;
		
	}

}
