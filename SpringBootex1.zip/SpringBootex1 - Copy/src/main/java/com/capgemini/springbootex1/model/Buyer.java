package com.capgemini.springbootex1.model;

public class Buyer {
	
	int bid;
	String bname;
	String bcity;
	String bstate;
	public Buyer(int bid, String bname, String bcity, String bstate) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bcity = bcity;
		this.bstate = bstate;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBcity() {
		return bcity;
	}
	public void setBcity(String bcity) {
		this.bcity = bcity;
	}
	public String getBstate() {
		return bstate;
	}
	public void setBstate(String bstate) {
		this.bstate = bstate;
	}
	
	

}
