package com.cg.eis.bean;

public class Employee {
	public int id;
    public String name;
    public int salary;
    public String designation;
    public String insuranceScheme;

    public Employee() {}


}
