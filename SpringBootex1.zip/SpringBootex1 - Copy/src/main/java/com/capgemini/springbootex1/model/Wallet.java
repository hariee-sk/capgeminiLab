package com.capgemini.springbootex1.model;

public class Wallet {

	int walId;
	String walType;
	float balance;
	public Wallet(int walId, String walType, float balance) {
		super();
		this.walId = walId;
		this.walType = walType;
		this.balance = balance;
	}
	public int getWalId() {
		return walId;
	}
	public void setWalId(int walId) {
		this.walId = walId;
	}
	public String getWalType() {
		return walType;
	}
	public void setWalType(String walType) {
		this.walType = walType;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	
}
