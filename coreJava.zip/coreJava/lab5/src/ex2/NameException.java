package ex2;

public class NameException extends Exception {
	  NameException(String s) 
	  {
		  super(s);
		  }

}