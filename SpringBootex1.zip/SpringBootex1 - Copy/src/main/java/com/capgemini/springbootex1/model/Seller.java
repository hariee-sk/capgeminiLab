package com.capgemini.springbootex1.model;

public class Seller {

	private int sid;
	private String sname;
	private String scity;
	private String sstate;
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	public String getSstate() {
		return sstate;
	}
	public void setSstate(String sstate) {
		this.sstate = sstate;
	}
	public Seller(int sid, String sname, String scity, String sstate) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.scity = scity;
		this.sstate = sstate;
	}
	
	
	
}
