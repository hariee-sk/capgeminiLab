package com.capgemini.lab8;


public class MainClass {
	
	public static void main(String[] args) {
		TimeThreadClass ttc=new TimeThreadClass();
		ttc.run();
	}
}