package com.capgemini.ex2;


public interface Space {
	
	 String addSpace();

}