package com.capgemini.ex1;

public class SavingsAccount extends Account {
	
	final float minBal= 500;
	

}
