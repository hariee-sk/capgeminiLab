package com.capgemini.ex4;

public interface Factorial {
	int test(int n);

}