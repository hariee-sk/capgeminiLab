package ex1;

public class InvalidAgeException extends Exception {
	InvalidAgeException(String s)
	{
		super(s);
	}
}
