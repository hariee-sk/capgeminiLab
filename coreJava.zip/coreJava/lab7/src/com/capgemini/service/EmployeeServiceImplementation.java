package com.capgemini.service;


import com.capgemini.bean.*;
import com.capgemini.hash.*;

public class EmployeeServiceImplementation implements EmployeeService {
    EmployeeHash eh = new EmployeeHash();

    public boolean addEmployee(Employee e) {
        return eh.addEmployee(e);
    }

    public String findInsuranceScheme(double sal, String desg) {
        return eh.findInsuranceScheme(sal, desg);

    }

    public Employee showEmployee(int id) {
        return eh.showEmployee(id);
    }


}