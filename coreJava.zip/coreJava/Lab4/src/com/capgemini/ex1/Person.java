package com.capgemini.ex1;



public class Person {

	private String pname;
	private float age;
	private float initialBal;
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public float getInitialBal() {
		return initialBal;
	}
	public void setInitialBal(float initialBal) {
		this.initialBal = initialBal;
	}

	Person p = new Person();
	Account a = new Account();
	

	public void createAccount() {
		Person p = new Person();
		Account a = new Account();
		p.setPname("smith");
		p.setAge(35);
		p.setInitialBal(2000);
		a.setAccNum(84313831);
		
		System.out.println("Name - "+p.getPname()+"age - "+p.getAge()+"Initial balance - "+p.getInitialBal());
		System.out.println("account created //");
		
		Person p1 = new Person();
			
		p1.setPname("kathy");
		p1.setAge(28);
		p1.setInitialBal(3000);
		System.out.println("Name - "+p1.getPname()+"age - "+p1.getAge()+"Initial balance - "+p1.getInitialBal());
		System.out.println("account created //");
		
		
	}
	public void deposit() {
		float balance = 2000+p.getInitialBal();
		System.out.println("the balance = "+balance);
	}
	

		
	
}
