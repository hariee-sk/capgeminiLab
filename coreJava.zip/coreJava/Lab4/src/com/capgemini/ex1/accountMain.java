package com.capgemini.ex1;

public class accountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person per = new Person();
		per.createAccount();
		per.deposit();

	}

}
