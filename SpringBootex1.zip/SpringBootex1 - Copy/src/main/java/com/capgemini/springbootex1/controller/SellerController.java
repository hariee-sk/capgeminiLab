package com.capgemini.springbootex1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springbootex1.model.Seller;

@RestController
public class SellerController {
	
	@RequestMapping("/seller")
	public List<Seller> showSellerDetails(){
		Seller sel= new Seller(1,"Hari" ,"Chennai", "Tamilnadu");
		Seller sel1= new Seller(2,"nishant" ,"lucknow", "Uttarpradesh");
		Seller sel2= new Seller(3,"Safana" ,"Sholingur", "Kerala");
		
		List<Seller> sellList = new ArrayList<Seller>();
		sellList.add(sel2);
		sellList.add(sel1);
		sellList.add(sel);
		
		return sellList;
		
	}

}
