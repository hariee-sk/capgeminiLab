package com.capgemini.ex3;


public interface UserClass {
	 boolean checkUserName();

}
