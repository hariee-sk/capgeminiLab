package com.capgemini.springbootex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootex1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
