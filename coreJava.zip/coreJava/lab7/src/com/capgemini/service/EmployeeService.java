  
package com.capgemini.service;

import com.capgemini.bean.Employee;

public interface EmployeeService {
	 public boolean addEmployee(Employee e);
	    public String findInsuranceScheme(double sal, String desg);
	    public Employee showEmployee(int id);

}