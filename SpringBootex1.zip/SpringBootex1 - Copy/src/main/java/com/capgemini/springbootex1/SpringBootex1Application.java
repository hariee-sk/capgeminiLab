package com.capgemini.springbootex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootex1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootex1Application.class, args);
	}

}
