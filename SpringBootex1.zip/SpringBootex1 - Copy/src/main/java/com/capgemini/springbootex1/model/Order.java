package com.capgemini.springbootex1.model;

public class Order {

	int ordId;
	String ordname;
	float totalAmt;
	public Order(int ordId, String ordname, float totalAmt) {
		super();
		this.ordId = ordId;
		this.ordname = ordname;
		this.totalAmt = totalAmt;
	}
	public int getOrdId() {
		return ordId;
	}
	public void setOrdId(int ordId) {
		this.ordId = ordId;
	}
	public String getOrdname() {
		return ordname;
	}
	public void setOrdname(String ordname) {
		this.ordname = ordname;
	}
	public float getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(float totalAmt) {
		this.totalAmt = totalAmt;
	}
	
	
}
