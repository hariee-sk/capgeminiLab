package com.capgemini.springbootex1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springbootex1.model.Buyer;

@RestController
public class BuyerController {
	

	@RequestMapping("/buyer")
	public List<Buyer> showBuyerDetails(){
		Buyer buy = new Buyer(55, "Mahesh","bangalore", "Karnataka");
		Buyer buy1 = new Buyer(88, "Thangathora","hydrabad", "Telangana");
		Buyer buy2 = new Buyer(44, "Somasundaram","kanyakumari", "Tamilnadu");
		
		List<Buyer> buyList = new ArrayList<Buyer>();
		buyList.add(buy2);
		buyList.add(buy1);
		buyList.add(buy);
		
		return buyList;
		
	}
}
