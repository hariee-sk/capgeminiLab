package lab6;

import java.util.ArrayList;
import java.util.Collections;

public class Exercise5 {

	public static int getSecondSmallest(int[] arr) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> alist=new ArrayList<Integer>();
		for (int i : arr)
		{
		   alist.add(i);
		}
		Collections.sort(alist);
		int secondSmallest = alist.get(1);
		
		return secondSmallest;
	}
		
}